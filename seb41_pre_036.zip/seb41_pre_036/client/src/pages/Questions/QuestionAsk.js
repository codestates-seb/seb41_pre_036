import React from "react";

export default function QuestionAsk() {
  return <div>QuestionAsk</div>;
}

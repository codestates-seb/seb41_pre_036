import React from "react";

export default function QuestionDetail() {
  return <div>QuestionDetail</div>;
}

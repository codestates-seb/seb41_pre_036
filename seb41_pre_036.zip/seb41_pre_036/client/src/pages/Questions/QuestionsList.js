import React from "react";

export default function QuestionsList() {
  return <div>QuestionsList</div>;
}

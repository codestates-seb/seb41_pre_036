import React from "react";

export default function Signup() {
  return <div>Signup</div>;
}

import React from "react";

export default function Tags() {
  return <div>Tags</div>;
}

package member.repository;


import member.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
    public static Optional<Member> findByEmail(String email) {
        return null;
    }

    public Optional<Member> findByUserId(String userId);

    public Member findByEmailAndPassword(String email, String password);

    @Query(value = "SELECT email FROM user WHERE user.active != true",nativeQuery = true)
    public Member getOnlyClosedUser(@Param("email") String email);
}

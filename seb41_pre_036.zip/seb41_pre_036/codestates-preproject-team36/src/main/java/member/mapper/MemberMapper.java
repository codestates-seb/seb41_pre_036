package member.mapper;


import member.dto.*;
import member.entity.Member;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MemberMapper {
  
     Member memberPostDtoToMember(MemberPostDto memberPostDto);
     Member memberPatchDtoToMember(MemberPatchDto memberPatchDto);

     Member memberLoginDtoToMember(MemberLoginDto memberLoginDto);
     Member memberEmailDtoToMember(MemberEmailDto memberEmailDto);
     MemberResponseDto memberToMemberResponseDto(Member member);














}


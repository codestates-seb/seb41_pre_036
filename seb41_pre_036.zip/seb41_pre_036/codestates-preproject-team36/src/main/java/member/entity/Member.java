package member.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.aspectj.weaver.patterns.TypePatternQuestions;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.data.domain.Auditable;

import javax.persistence.*;

@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "members")
public class Member extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter
    private String userId;

    @Column(nullable = false, updatable = false, unique = true)
    private String email;

    @Column(nullable = false, updatable = false)
    private String password;

    @Column
    public String userNickname;


    @OneToMany(mappedBy = "member")
    @ToString.Exclude
    @LazyCollection(LazyCollectionOption.FALSE)
    @JsonIgnore
    private List<Question> questionList;

    @OneToMany(mappedBy = "member")
    @ToString.Exclude
    @LazyCollection(LazyCollectionOption.FALSE)
    @JsonIgnore
    private List<Answer> answerList;


    @Builder
    public Member(String userId, String email, String password, String userNickname) {
        this.userId = userId;
        this.email = email;
        this.password = password;
        this.userNickname = userNickname;
    }

    public void addQuestionList(TypePatternQuestions.Question question){
        this.questionList.add(question);
    }

    public void addAnswerList(Answer answer){
        this.answerList.add(answer);
    }

}

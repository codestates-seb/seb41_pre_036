package member.service;

import member.repository.MemberRepository;

public class MemberDetailsServiceImpl extends MemberDetailsService {
    public MemberDetailsServiceImpl(MemberRepository MemberRepository) {
        isCredentialsNonExpired(MemberRepository);
    }
}

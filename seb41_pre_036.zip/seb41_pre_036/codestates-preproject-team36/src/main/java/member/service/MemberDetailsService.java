package member.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import member.entity.Member;
import member.repository.MemberRepository;

import java.util.Optional;

@Component
@RequiredArgsConstructor

public class MemberDetailsService extends MemberDetails {
    private MemberRepository memberRepository;
    private final CustomAuthorityUtils authorityUtils;


    @Override
    public MemberDetails loadMemberByMembername(String membername) throws MembernameNotFoundException {
        Optional<Member> optionalMember = MemberRepository.findByEmail(membername);
        Member findMember = optionalMember.orElseThrow(() -> new BusinessLogicException(ExceptionCode.USER_NOT_FOUND));
        return new MemberDetails(findMember);
    }

    public final class MemberDetails extends Member implements MemberDetailsService {
        MemberDetails(Member member) {
            setUserId(member.getUserId());
            setEmail(member.getEmail());
            setPassword(member.getPassword());
        }

        @Override
        public String getuserId() { return getEmail(); }

        @Override
        public boolean isAccountNonExpired() {
            return true;
        }

        @Override
        public boolean isAccountNonLocked() {
            return true;
        }

        @Override
        public boolean isCredentialsNonExpired(MemberRepository memberRepository) {
            return true;
        }

        @Override
        public boolean isEnabled() {
            return true;
        }
    }
}
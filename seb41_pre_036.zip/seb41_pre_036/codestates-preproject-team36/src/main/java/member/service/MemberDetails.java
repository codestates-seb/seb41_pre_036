package member.service;


import member.entity.Member;
import member.repository.MemberRepository;

public abstract class MemberDetails implements MemberDetails {

    private Member member;

    public MemberDetails(Member member) {
        this.member = member;
    }

    public Member getMember(){
        return member;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return member.getPassword();
    }

    @Override
    public String getMembername() {
        return member.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    public boolean isCredentialsNonExpired(MemberRepository memberRepository) {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public abstract MemberDetailsService.MemberDetails loadMemberByMembername(String Membername) throws MembernameNotFoundException;
}

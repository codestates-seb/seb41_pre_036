package com.codestates.preproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodestatesPreprojectTeam36ApplicationTests {

	@Test
	void contextLoads() {


	}

}

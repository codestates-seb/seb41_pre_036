---
name: Custom issue template
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

### 만들고자 하는 기능이 무엇인가요?
ex) Todo 생성 기능

### 해당 기능을 구현하기 위해 할 일이 무엇인가요?
1. [ ] Job1
2. [ ] Job2
3. [ ] Job3

### 예상 작업 시간
ex) 3h
